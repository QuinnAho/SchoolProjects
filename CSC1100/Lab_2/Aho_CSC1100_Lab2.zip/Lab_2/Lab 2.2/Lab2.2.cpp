/*


Quinn Aho


*/


#include <iostream>

using namespace std;

int main()
{
	float num1, num2;
	
    //User enters numbers
	cout << "Enter two numbers: ";
	cin >> num1 >> num2;

    //Reverses the numbers with a string to space out the two numbers.
	cout <<"After swapping numbers are: " << num2 << " " << num1;


}
